# Bekzod Umarov — Personal Website (Ready to Use)

## Included
- `index.html` (your website)
- `photo.jpg` (placeholder — replace with your real photo)
- `cv.pdf` (placeholder — replace with your real CV)

## LinkedIn
- LinkedIn button is already connected to: https://www.linkedin.com/in/bekzod-umarov-a72a4638a/

## Run locally
- Open `index.html` in your browser.

## Add your real photo (recommended)
LinkedIn blocks direct downloading of profile photos from outside the site, so the easiest way is:

1) Open your LinkedIn profile
2) Click your profile picture → open it
3) Download/Save the image to your computer
4) Replace `photo.jpg` in this folder with your real photo (keep the same filename)
5) Refresh the page

Alternative: you can upload your photo here in chat, and I’ll insert it into the package for you.

## Add your CV
- Replace `cv.pdf` with your real CV PDF (keep the same filename).

## Publish (free)
### Netlify (fastest)
- Netlify → Add new site → Deploy manually → Drag & drop the folder contents.

### GitHub Pages
- Create a GitHub repo
- Upload the files
- Settings → Pages → Deploy from branch (main/root)
